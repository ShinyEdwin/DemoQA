package RestAssured;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateAuthRequest {
    RequestSpecification request; 
    Response response; 

    @Given("Enter the BaseUri")
    public void enterbaseURI() {
        RestAssured.baseURI = "https://demoqa.com/Account/v1/Authorized";
        request = RestAssured.given().contentType("application/json"); 
    }

    @When("Enter the correct credentials")
    public void entercredentials() {
        request.body("{\r\n"
                + "  \"userName\": \"JadenS\",\r\n"
                + "  \"password\": \"Welcome1$\"\r\n"
                + "}");
    }

    @And("Send the request")
    public void sendRequest() {
        response = request.post(); 
    }

    @Then("Validate the response")
    public void validateResponse() {
        response.then().assertThat().statusCode(200);
        
    }
}
