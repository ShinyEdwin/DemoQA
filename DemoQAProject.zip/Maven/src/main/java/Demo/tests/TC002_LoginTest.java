package Demo.tests;

import org.testng.annotations.Test;
import Demo.base.BaseClass;
import Demo.page.LoginPage;
  

public class TC002_LoginTest extends BaseClass {
	@Test
	public void runLoginTest()
	{
		LoginPage login= new LoginPage(driver);
		login.Login("JadenS","Welcome1$");
		login.logout();
	}

}
