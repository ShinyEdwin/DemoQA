package Demo.tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import Demo.base.BaseClass;
import Demo.page.RegistrationPage;

public class TC001_UserRegistration extends BaseClass {
	@Test
	public void runRegisterTest()
	{
	RegistrationPage register= new RegistrationPage(driver);
	register.Register("Shiny","Edwin","ShinyE","Welcome1$");
	register.Register("Priya", "Selvam", "PriyaS", "123456");
	String errorMessage = register.getErrorMessage(); 
    Assert.assertEquals(errorMessage, "Error: Invalid input"); 

	
	}
}
