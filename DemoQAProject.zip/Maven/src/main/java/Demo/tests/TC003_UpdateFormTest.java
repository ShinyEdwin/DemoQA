package Demo.tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import Demo.base.BaseClass;
import Demo.page.LoginPage;


public class TC003_UpdateFormTest extends BaseClass {
	@Test
public void runFormUpdateTest()
{
	LoginPage login= new LoginPage(driver);
	login.Login("JadenS","Welcome1$").FillForm("Shiny","Edwin","123@gmail.com","123456789");
	
	
}
}
