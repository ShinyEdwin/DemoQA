package Demo.page;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Demo.base.BaseClass;

public class LoginPage extends BaseClass {
	
	public LoginPage (RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	
	public FillFormPage Login(String user,String password)
	{
		
		driver.findElement(By.id("userName")).sendKeys(user);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//button[@id='login']")).click();
		String username=driver.findElement(By.id("userName-value")).getText();
		if(user.equals(username))
		{
			System.out.println("Login is successfull");
		}
		else
		{
			System.out.println("Login failed");
		}
		return new FillFormPage(driver);
	}
	
	public void logout()
	{
		driver.findElement(By.xpath("//button[text()='Log out']")).click();
	}
}