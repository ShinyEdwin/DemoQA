package Demo.page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import Demo.base.BaseClass;

public class FillFormPage extends BaseClass {
	
	public FillFormPage (RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	
	public LogoutPage FillForm(String fname,String lname,String mailid,String pnumber)
	{
		driver.findElement(By.xpath("//div[text()='Forms']")).click();
		driver.findElement(By.xpath("//span[text()='Practice Form']")).click();
		WebElement body = driver.findElement(By.tagName("body"));
		body.sendKeys(Keys.PAGE_DOWN);
		driver.findElement(By.xpath("//input[@id='firstName']")).sendKeys(fname);
		driver.findElement(By.xpath("//input[@id='lastName']")).sendKeys(lname);
		driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys(mailid);
		driver.findElement(By.xpath("//label[@for='gender-radio-2']")).click();
		driver.findElement(By.xpath("//input[@id='userNumber']")).sendKeys(pnumber);
		driver.findElement(By.xpath("//input[@id='dateOfBirthInput']")).click();
		WebElement month = driver.findElement(By.xpath("//select[@class='react-datepicker__month-select']"));
		Select monthselect = new Select(month);
		monthselect.selectByVisibleText("November");
		WebElement year = driver.findElement(By.xpath("//div[@class='react-datepicker__year-dropdown-container react-datepicker__year-dropdown-container--select']/select"));
		Select yearselect = new Select(year);
		yearselect.selectByValue("1995");
		driver.findElement(By.xpath("//div[@class='react-datepicker__day react-datepicker__day--010']")).click();
		//body.sendKeys(Keys.PAGE_DOWN);
		driver.findElement(By.xpath("//label[text()='Reading']")).click();
		driver.findElement(By.id("currentAddress")).sendKeys("No.1,ABC,City-600118");
		
		driver.findElement(By.xpath("//div[@class=' css-yk16xz-control']")).click();
		driver.findElement(By.xpath("//div[text()='NCR']")).click();
		driver.findElement(By.xpath("//div[text()='Select City']")).click();
		driver.findElement(By.xpath("//div[text()='Delhi']")).click();
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		String confirmation=driver.findElement(By.xpath("//div[@id='example-modal-sizes-title-lg']")).getText();
		
		if(confirmation.contains("Thanks"))
		{
			System.out.println("Form submission is successfull");
		}
		else
		{
			System.out.println("Form submission failed");
		}
		return new LogoutPage(driver);
	}

}
