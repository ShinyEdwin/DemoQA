package Demo.page;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import Demo.base.BaseClass;

public class RegistrationPage extends BaseClass {
	public RegistrationPage (RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	
	public LoginPage Register(String fname,String lname,String uname,String pwd)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement body = driver.findElement(By.tagName("body"));
		body.sendKeys(Keys.PAGE_DOWN);
		WebElement newUserButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("newUser")));
		newUserButton.click();
		driver.findElement(By.id("firstname")).sendKeys(fname);
		driver.findElement(By.id("lastname")).sendKeys(lname);
		driver.findElement(By.id("userName")).sendKeys(uname);
		driver.findElement(By.id("password")).sendKeys(pwd);
		WebElement frame = driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']"));
		driver.switchTo().frame(frame);
		driver.findElement(By.xpath("//span[@class='recaptcha-checkbox goog-inline-block recaptcha-checkbox-unchecked rc-anchor-checkbox']")).click();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//button[@id='register']")).click();
		
		return new LoginPage(driver);
	}
	public String getErrorMessage() {
        
        return driver.findElement(By.partialLinkText("Passwords must have")).getText();
	}

	
}
