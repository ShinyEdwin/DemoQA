package Demo.page;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Demo.base.BaseClass;

public class LogoutPage extends BaseClass{
	
	public LogoutPage (RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	
	public LogoutPage logout()
	{
		driver.findElement(By.xpath("//button[text()='Log out']")).click();
		return this;
	}
	

}
